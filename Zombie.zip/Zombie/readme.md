# Boids(Flock)
-------------
1.Separacion
2.Alineamiento
3.Cohesión

4.Seek
5.Arrive
6.Flee
7.Edges
8.Path following
9.Wander
10.Obstacle Avoidance
